package account;

import java.sql.SQLException;
import java.util.List;

public interface IAccountDao {
	public AccountBean findById(String Id) throws SQLException;
	public List<AccountBean>getAll() throws SQLException;
}
