package account;


import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.naming.InitialContext;
import javax.servlet.ServletOutputStream;
import javax.sql.DataSource;



public class AccountDao implements IAccountDao {
	String resource = "java:comp/env/jdbc/memberDB";
	private static final String SelectOne = "SELECT * FROM Account WHERE id=?";
	private static final String SelectAll = "SELECT * FROM Account";

	public AccountBean findById(String id) throws SQLException {
		AccountBean acc = null;
		try {
			InitialContext context = new InitialContext();
			DataSource ds = (DataSource) context.lookup(resource);

			try (Connection conn = ds.getConnection(); 
				PreparedStatement pstmt = conn.prepareStatement(SelectOne);
					
					) {
				pstmt.setString(1, id);
				try (
					ResultSet rs = pstmt.executeQuery();
						) 
				{
					if (rs.next()) {
						acc = new AccountBean();
						acc.setId(rs.getString("ID"));
						acc.setAcc(rs.getString("Account"));
						acc.setPw(rs.getString("PW"));
					}
				}
			} catch (Exception e) {

			}
		} catch (Exception e) {

		}
		return acc;
	}
	
	public List<AccountBean>getAll() throws SQLException{
		AccountBean acc = null;
//		byte[] img = null;
//		ServletOutputStream sos = null;
		List<AccountBean>accs = new ArrayList<AccountBean>();
		try {
			InitialContext context = new InitialContext();
			DataSource ds = (DataSource) context.lookup(resource);

			try (Connection conn = ds.getConnection(); 
				PreparedStatement pstmt = conn.prepareStatement(SelectAll);) {
				try (ResultSet rs = pstmt.executeQuery();) 
				{
					 
					 
					
					while(rs.next()) {
						
						
						Blob blob = rs.getBlob("ProPic");
						InputStream inputStream = blob.getBinaryStream();
						ByteArrayOutputStream baos = new ByteArrayOutputStream();
						byte[] buffer = new byte[4096];
						int bytesRead = -1;
						while ((bytesRead = inputStream.read(buffer)) != -1) {
							baos.write(buffer, 0, bytesRead);
						}
						byte[] imageBytes = baos.toByteArray();
						String imgb64 = Base64.getEncoder().encodeToString(imageBytes);
						inputStream.close();
						
						Blob blob2 =rs.getBlob("PetPic");
						InputStream inputStream2 = blob2.getBinaryStream();
						ByteArrayOutputStream baos2 = new ByteArrayOutputStream();
						byte[] buffer2 = new byte[4096];
						int bytesRead2 = -1;
						while ((bytesRead2 = inputStream2.read(buffer2)) != -1) {
							baos2.write(buffer2, 0, bytesRead2);
						}
						byte[] imageBytes2 = baos2.toByteArray();
						String petPics = Base64.getEncoder().encodeToString(imageBytes2);
						inputStream2.close();
						baos2.close();
						
						baos.close();
						acc = new AccountBean();
						acc.setId(rs.getString("ID"));
						acc.setAcc(rs.getString("Account"));
						acc.setPw(rs.getString("PW"));
						acc.setImgb64(imgb64);
						acc.setPetPic(petPics);
						acc.setZodiac(rs.getString("Zodiac"));
//						acc.setImg(rs.getBytes("ProPic"));
						accs.add(acc);
						
					}
					
				}
			} catch (Exception e) {
			}
		} catch (Exception e) {
		}
		
		return accs;
		
	}
}
