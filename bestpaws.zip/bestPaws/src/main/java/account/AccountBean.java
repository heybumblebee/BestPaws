package account;

public class AccountBean {
	private String id;
	private String acc;
	private String pw;
	private String imgb64;
	private String zodiac;
	private String petPic;
	public String getPetPic() {
		return petPic;
	}
	public void setPetPic(String petPic) {
		this.petPic = petPic;
	}
	public AccountBean() {
		super();
	}
	public AccountBean(String zodiac) {
		this.zodiac = zodiac;
	}
	
	public String getZodiac() {
		return zodiac;
	}
	public void setZodiac(String zodiac) {
		this.zodiac = zodiac;
	}
	public String getImgb64() {
		return imgb64;
	}
	public void setImgb64(String imgb64) {
		this.imgb64 = imgb64;
	}
	//	private byte[] img;
//	public byte[] getImg() {
//		return img;
//	}
//	public void setImg(byte[] img) {
//		this.img = img;
//	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAcc() {
		return acc;
	}
	public void setAcc(String acc) {
		this.acc = acc;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
}
