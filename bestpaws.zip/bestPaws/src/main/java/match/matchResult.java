package match;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import account.AccountBean;
import service.AccountService;



@WebServlet("/match/matchResult.do")
public class matchResult extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
   
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}
	public void processRequest(HttpServletRequest request,
            HttpServletResponse response) throws IOException, 
	ServletException {
	    // 說明瀏覽器送來之文字資料的編碼
		request.setCharacterEncoding("UTF-8");
	    // 讀取使用者在 <input name='userName' ...>標籤內所輸入的資料，放入變數 name內
//		String zodiac = request.getParameter("zodiac");
//		// name = new String(name.getBytes("ISO-8859-1"), "UTF-8");
//	    // 如果瀏覽器沒有送來名為userName的資料 或 瀏覽器有送來名為userName的資料，但
//	    // 去掉該資料的頭尾空白後，長度為 0		
//		if (zodiac == null || zodiac.length() == 0) {
//			name = DEFAULT_NAME;
//		}
//		String email = request.getParameter("eMail");
//	    // 如果瀏覽器沒有送來名為eMail的資料 或 瀏覽器有送來名為eMail的資料，但
//	    // 去掉該資料的頭尾空白後，長度為 0		
//		if (email == null ||  email.length() == 0) {
//			email = DEFAULT_EMAIL;
//		}
//		String tel = request.getParameter("tel");
//	    // 如果瀏覽器沒有送來名為tel的資料 或 瀏覽器有送來名為tel的資料，但
//	    // 去掉該資料的頭尾空白後，長度為 0		
//		if (tel == null || tel.length() == 0) {
//			tel = DEFAULT_TEL;
//		}
		AccountService as = new AccountService();
		try {
			List<AccountBean> list = as.getAll();
			request.setAttribute("allAccounts", list);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String zodiac = request.getParameter("zodiac");
	    // 將四樣資訊裝入CustomerBean型別的物件cust內		
		AccountBean ab = new AccountBean(zodiac);
	    // 將cust物件暫存到請求物件內，成為它的屬性物件，屬性物件可以與別的程式共用。		
        request.setAttribute("zodiac",ab);
        // 程式的執行順序移轉到/ch02/displayCustomerInfo.jsp內        
		RequestDispatcher rd = request.getRequestDispatcher("/match/matchResult.jsp");
		rd.forward(request, response);		
	}
	
	
	

}
