package match;

public class matchResultModel implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
	String zodiac;
	public matchResultModel(String zodiac) {
		this.zodiac = zodiac;
	}
	
}
