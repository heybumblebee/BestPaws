package address;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class AddressBean implements Serializable {
	private String city;

	public AddressBean() {

	}

	public AddressBean(String city) {

		this.city = city;

	}

	public List<AddressBean> loadData(String country) {
		List<AddressBean> actorList = new ArrayList<AddressBean>();
		
		
		String resource = "java:comp/env/jdbc/memberDB";
		InitialContext context;
		try {
			context = new InitialContext();
			DataSource ds = (DataSource) context.lookup(resource);
			Connection conn = ds.getConnection(); 
			String q = "Select City from dbo.Address where Country='" + country + "'";
			PreparedStatement pstmt = conn.prepareStatement(q);
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
				
				AddressBean ab = new AddressBean(rs.getString("City"));
				actorList.add(ab);
				
			}
			
		} catch (NamingException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return actorList;

			
		}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	

}
