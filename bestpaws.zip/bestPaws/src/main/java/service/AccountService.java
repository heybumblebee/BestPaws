package service;

import java.sql.SQLException;
import java.util.List;

import account.AccountBean;
import account.AccountDao;
import account.IAccountDao;

public class AccountService implements IAccountService{

	@Override
	public AccountBean findById(String Id) throws SQLException {
		IAccountDao dao = new AccountDao();
		return dao.findById(Id);
	}

	@Override
	public List<AccountBean> getAll() throws SQLException {
		IAccountDao dao = new AccountDao();
		return dao.getAll();
	}

}
