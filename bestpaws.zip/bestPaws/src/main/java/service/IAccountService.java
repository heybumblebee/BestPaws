package service;

import java.sql.SQLException;
import java.util.List;

import account.AccountBean;

public interface IAccountService {
	public AccountBean findById(String Id) throws SQLException;
	public List<AccountBean>getAll() throws SQLException;
}
