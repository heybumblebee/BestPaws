package importimg;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

public class ImportImage {

	public static void main(String[] args) {
		
		String qryStr="UPDATE dbo.Account SET ProPic = ?, ProPicFileName = ? WHERE ID=?"; //加上 where memberno=? 依會員ID編號插入圖片
		String imgDir = "C:\\Users\\ALICE\\Desktop\\BestPaws\\memberpic"; //圖片資料夾
																	   //修改成自己的資料表與欄位
		File f = new File(imgDir);
		File[] flist = f.listFiles(); //取得資料夾內檔案清單
		FileInputStream fis=null; //finally close

		try (Connection conn = DriverManager.getConnection(
				"jdbc:sqlserver://localhost:1433;databaseName=BestPaws", "andy3", "andy3");
			 Statement statement = conn.createStatement();
			 PreparedStatement stmt = conn.prepareStatement(qryStr);
		) {
			
//			conn.setAutoCommit(false);
//			statement.execute("delete from Files");
//			File file = new File("d:/JDBC/files_read/xxx.jpg");
			
			//可用會員ID來跑for迴圈 使用全數字ID 或放入將ID放入陣列遍歷
			for(int i=0,len=flist.length;i<len;i++)
			{	
				
//				System.out.println(flist[i].getAbsolutePath()); //檔案絕對路徑
				System.out.println(flist[i].getName()); //檔案名稱
//				System.out.println(flist[i].length()); //檔案大小 型態long 單位kb 1024kb=1mb 1024mb=1gb b=8bits一位元組
				File file = new File(flist[i].getAbsolutePath());	//getAbsolutePath()取得字串 getAbsoluteFile()取得file物件			
				fis = new FileInputStream(file);
				stmt.setBinaryStream(1, fis);
				stmt.setString(2, file.getName());
				stmt.setInt(3, i+1);
				stmt.execute();
			}
//			conn.commit();

//            PreparedStatement_BatchUpdate.printResult(updated); //列印出執行結果
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		 

	}

}
