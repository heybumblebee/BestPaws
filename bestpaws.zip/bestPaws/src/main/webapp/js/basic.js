/**
 * 
 */

$(document).ready(function(){
	$("#updateUsername").submit(function(){
		
		$.ajax({
			url:'UpdateUsername',
			type:'POST',
			dataType:'json',
			data:$('#updateUsername').serialize(),
			success: function(data){
				if(data.isValid){
					$('#displayName').html('yourname is'+ data.username);
					$('#displayName').slideDown(5000);
				}
				else{
					alert('Please Enter');
				}
			}
		})
		return false;
	})
	
})